@class NSCache, NSString, TSPComponent, TSPObjectContext, NSHashTable, NSObject, NSMapTable;
@protocol OS_dispatch_queue;

@interface TSPComponentManager : NSObject <TSPComponentDelegate, TSPObjectModifyDelegate> {
    _Atomic int _ignoreCachedObjectEvictionCount;
    BOOL _isTornDown;
    NSObject<OS_dispatch_queue> *_componentQueue;
    NSHashTable *_components;
    NSMapTable *_componentDictionary;
    NSCache *_componentCache;
    TSPComponent *_viewStateComponent;
    NSObject<OS_dispatch_queue> *_readFlushedComponentQueue;
}

@property (readonly, weak, nonatomic) TSPObjectContext *context;
@property (readonly, nonatomic) TSPComponent *packageMetadataComponent;
@property (readonly, nonatomic) TSPComponent *documentComponent;
@property (readonly, nonatomic) TSPComponent *documentObjectContainerComponent;
@property (readonly, nonatomic) TSPComponent *documentMetadataComponent;
@property (readonly, nonatomic) TSPComponent *supportComponent;
@property (readonly, nonatomic) TSPComponent *supportObjectContainerComponent;
@property (readonly, nonatomic) TSPComponent *supportMetadataComponent;
@property (retain) TSPComponent *viewStateComponent;
@property (readonly, nonatomic) unsigned long long componentCount;
@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

+ (id)componentManagersPerformingCacheOperationOnCurrentThread;

- (void)dealloc;
- (id)init;
- (void).cxx_destruct;
- (id)initWithContext:(id)a0;
- (BOOL)isActive;
- (void)tearDown;
- (id)objectForIdentifier:(long long)a0;
- (void)beginIgnoringCachedObjectEviction;
- (void)endIgnoringCachedObjectEviction;
- (void)suspendLoadingModifiedFlushedComponentsAndWait;
- (void)resumeLoadingModifiedFlushedComponents;
- (void)enumerateComponents:(id /* block */)a0;
- (void)willModifyObject:(id)a0 options:(unsigned long long)a1;
- (void)dirtyComponents:(id)a0;
- (void)retrieveOrCreateComponentForRootObject:(id)a0 queue:(id)a1 completion:(id /* block */)a2;
- (void)componentForRootObjectOfLazyReference:(id)a0 queue:(id)a1 completion:(id /* block */)a2;
- (void)componentForRootObjectIdentifier:(long long)a0 queue:(id)a1 completion:(id /* block */)a2;
- (void)dirtyAllComponentsForDocumentUpgradeInPackage:(unsigned char)a0;
- (unsigned long long)objectTargetType;
- (void)loadComponent:(const void *)a0 package:(id)a1;
- (void)performCacheOperationUsingBlock:(id /* block */)a0;
- (id)rootComponentWithIdentifierImpl:(long long)a0 locator:(id)a1 packageIdentifier:(unsigned char)a2;
- (id)documentComponentImpl;
- (id)componentForRootObjectIdentifier:(long long)a0;
- (id)supportComponentImpl;
- (id)componentForRootObjectOfLazyReferenceImpl:(id)a0;
- (void)traverseComponentTreeFromRoot:(id)a0 accessor:(id /* block */)a1;
- (BOOL)isPerformingCacheOperation;
- (void)continueCacheOperationUsingBlock:(id /* block */)a0;
- (BOOL)shouldKeepAllCachedObjectsInMemory;
- (void)cacheComponent:(id)a0 isDiscardingContent:(BOOL)a1;
- (void)flushComponent:(id)a0 isDiscardingContent:(BOOL)a1;
- (void)didModifyFlushedComponent:(id)a0 forObject:(id)a1;
- (void)loadFromPackage:(id)a0 metadata:(id)a1;
- (id)componentForRootObjectOfLazyReference:(id)a0;
- (id)rootComponentForPackageIdentifier:(unsigned char)a0;
- (void)discardOrphanedComponents;
- (void)evictAllCachedObjects;

@end
