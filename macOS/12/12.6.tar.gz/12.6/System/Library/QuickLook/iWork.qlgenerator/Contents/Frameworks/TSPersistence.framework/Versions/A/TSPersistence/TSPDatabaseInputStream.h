@class NSString, NSObject;
@protocol OS_dispatch_queue;

@interface TSPDatabaseInputStream : NSObject <TSUStreamReadChannel, SFUInputStream> {
    NSObject<OS_dispatch_queue> *_readQueue;
    struct sqlite3_blob { } *_blob;
    int _offset;
    int _length;
}

@property (readonly) unsigned long long hash;
@property (readonly) Class superclass;
@property (readonly, copy) NSString *description;
@property (readonly, copy) NSString *debugDescription;

- (void)dealloc;
- (void)close;
- (void).cxx_destruct;
- (long long)offset;
- (void)seekToOffset:(long long)a0;
- (id)initWithBlob:(struct sqlite3_blob { } *)a0;
- (unsigned long long)readToBuffer:(char *)a0 size:(unsigned long long)a1;
- (BOOL)canSeek;
- (void)disableSystemCaching;
- (void)enableSystemCaching;
- (id)closeLocalStream;
- (void)readWithHandler:(id /* block */)a0;
- (void)readWithHandlerAndWait:(id /* block */)a0;

@end
