@interface TSKMacNSPopover : NSPopover

@end
